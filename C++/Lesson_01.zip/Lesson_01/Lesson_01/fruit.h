#define _CRT_SECURE_NO_WARNINGS

//#pragma once
#include <string.h>
typedef enum Color {RED, YELLOW, ORANGE, GREEN, NONE};

class Fruit
{
	private:
		char *name;
		Color color=NONE;
		float weight;

	public:
		/**/

		Fruit(const char* name, Color color=YELLOW) : color(color), weight(0.50)
		{
			this->name = new char[strlen(name) + 1];
			//strcpy(this->name, name);
			for (int i = 0; i <= strlen(name); i++)
				this->name[i] = name[i];/**/
		}

		Fruit(const char *name, Color color, float weight) :Fruit(name)
		{
			this->color = color;
			this->weight = weight;
		}



		const char* getName();
		Color getColor();
		float getWeight();

};

