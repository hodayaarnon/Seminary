#include "Fruit.h"


const char* Fruit::getName()
{
	return name;
}

Color Fruit::getColor()
{
	return color;
}

float Fruit::getWeight()
{
	return weight;
}